<?php

return array(
    'blog_id' => array(
        'value'        => '',
        'title'        => /*_w*/('Blog'),
        'description'  => '',
        'control_type' => waHtmlControl::RADIOGROUP,
        'options'      => array(
           /* see blogPostsWidget::getSettingsConfig() */
        ),
    ),
);