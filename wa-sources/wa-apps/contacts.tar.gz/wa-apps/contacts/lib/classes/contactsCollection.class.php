<?php

/**
 * @deprecated since version 1.1.0
 */
class contactsCollection extends waContactsCollection
{
}