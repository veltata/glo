<?php

class contactsViewHelper extends waAppViewHelper
{

} 