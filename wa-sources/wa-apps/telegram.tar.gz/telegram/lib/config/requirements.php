<?php

return array(
    'php' => array(
        'strict' => true,
        'version' => '>=5.6.0',
    ),
);