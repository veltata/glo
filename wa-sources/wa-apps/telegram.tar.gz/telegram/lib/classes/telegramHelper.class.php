<?php

class telegramHelper extends waAppConfig
{
    
}
