<?php

class telegramPlugin extends waPlugin
{
       
}
