<?php

return array(
	100 => _w("Not enough rights to work with current board"),
);