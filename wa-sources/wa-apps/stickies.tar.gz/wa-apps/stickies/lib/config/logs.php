<?php

return array(
    'board_add' => array(
        'name' => /*_w*/('created a new board')
    ),
    'board_edit' => array(
        'name' => /*_w*/('edited board')
    ),
    'board_delete' => array(
        'name' => /*_w*/('deleted board')
    ),
    'sticky_add' => array(
        'name' => /*_w*/('added a new sticky')
    ),
    'sticky_edit' => array(
        'name' => /*_w*/('edited sticky')
    ),
    'sticky_resize' => array(
        'name' => /*_w*/('resized sticky')
    ),
    'sticky_move_to_board' => array(
        'name' => /*_w*/('moved sticky to another board')
    ),
    'sticky_delete' => array(
        'name' => /*_w*/('deleted sticky')
    ),
    'sticky_move' => array(
        'name' => /*_w*/('moved sticky')
    ),
);