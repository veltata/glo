<?php 
return array(
    'name' => 'Stickies',
    'prefix' => 'stickies',
    'icon' => array(
        48 => 'img/stickies.png',
        96 => 'img/stickies96.png',
    ),
    'rights' => true,
    'mobile' => true,
    'version' => '1.1.1',
    'critical'=>'1.1.1',
    'vendor' => 'webasyst',
);