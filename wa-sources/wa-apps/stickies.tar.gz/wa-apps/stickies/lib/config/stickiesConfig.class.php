<?php
class stickiesConfig extends waAppConfig
{
}
