<?php

wa('webasyst');
class blogFrontendRegionsController extends webasystBackendRegionsController
{

}