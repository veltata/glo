<?php

class blogMyNavAction extends waMyNavAction
{
}