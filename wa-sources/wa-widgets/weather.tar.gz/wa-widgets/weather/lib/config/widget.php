<?php

return array(
    'name' => /*_w*/('Weather'),
    'size' => array('2x2', '1x1', '2x1'),
    'img' => 'img/weather.png',
    'version' => '1.2',
    'vendor' => 'webasyst',
);