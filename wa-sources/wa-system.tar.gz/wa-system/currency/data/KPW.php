<?php

return array(
    'code' => 'KPW',
    'sign' => '₩',
	'iso4217' => '408',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'North Korean won',
    'name' => array(
        'won',
    ),
    'frac_name' => array(
        'chon',
    )
);