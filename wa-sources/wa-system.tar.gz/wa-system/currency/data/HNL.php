<?php

return array(
    'code' => 'HNL',
    'sign' => 'L',
	'iso4217' => '340',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Honduran lempira',
    'name' => array(
        array('lempira', 'lempiras'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);