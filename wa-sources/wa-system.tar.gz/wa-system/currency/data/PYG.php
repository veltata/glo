<?php

return array(
    'code' => 'PYG',
    'sign' => '₲',
	'iso4217' => '600',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Paraguayan guarani',
    'name' => array(
        array('guarani', 'guaranies'),
    ),
    'frac_name' => array(
    )
);