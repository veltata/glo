<?php

return array(
    'code' => 'ISK',
    'sign' => 'kr',
	'iso4217' => '352',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Icelandic krona',
    'name' => array(
        array('krona', 'kronur'),
    ),
    'frac_name' => array(
    )
);