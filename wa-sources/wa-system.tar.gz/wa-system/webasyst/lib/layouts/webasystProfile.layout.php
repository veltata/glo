<?php

class webasystProfileLayout extends waLayout
{

}