<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.8.8',
    'critical'=>'1.8.8',
    'vendor' => 'webasyst',
    'csrf' => true,
);
