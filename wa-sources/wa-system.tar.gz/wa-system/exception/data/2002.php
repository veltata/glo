<?php
$message = 'Cannot connect to MySQL server.';
include('error.php');
