<?php 
$message = 'The requested URL was not found on this server.';
include('error.php');
